package com.example.screenoffrecorder

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {
    private val requestCode = 42
    private lateinit var status: TextView
    private lateinit var torchButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 48, 36, 36)
        }
        val title = TextView(this).apply {
            text = "Screen Off Recorder"
            textSize = 26f
        }
        status = TextView(this).apply {
            text = "Ready. Start recording while this app is open."
            textSize = 16f
            setPadding(0, 24, 0, 24)
        }
        val start = Button(this).apply {
            text = "START RECORDING"
            setOnClickListener { checkPermissionsAndStart() }
        }
        val stop = Button(this).apply {
            text = "STOP RECORDING"
            setOnClickListener {
                startService(Intent(this@MainActivity, RecordingService::class.java).setAction(RecordingService.ACTION_STOP))
                status.text = "Stop command sent. Check Movies/ScreenOffRecorder."
            }
        }
        torchButton = Button(this).apply {
            text = "FLASHLIGHT ON / OFF"
            setOnClickListener {
                startService(Intent(this@MainActivity, RecordingService::class.java).setAction(RecordingService.ACTION_TOGGLE_TORCH))
            }
        }
        val note = TextView(this).apply {
            text = "Start recording first. You can then lock the screen. Use the notification to return to the app and stop recording. Keep this app visible when starting; Android may restrict camera access if it is started in the background."
            textSize = 14f
            setPadding(0, 22, 0, 0)
        }
        layout.addView(title)
        layout.addView(status)
        layout.addView(start)
        layout.addView(stop)
        layout.addView(torchButton)
        layout.addView(note)
        setContentView(layout)
    }

    private fun checkPermissionsAndStart() {
        val permissions = mutableListOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) permissions.add(Manifest.permission.POST_NOTIFICATIONS)
        val missing = permissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, missing.toTypedArray(), requestCode)
        } else {
            startRecording()
        }
    }

    private fun startRecording() {
        val intent = Intent(this, RecordingService::class.java).setAction(RecordingService.ACTION_START)
        ContextCompat.startForegroundService(this, intent)
        status.text = "Starting recording…"
        Toast.makeText(this, "Recording is starting. Lock screen only after it begins.", Toast.LENGTH_LONG).show()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == this.requestCode) {
            if (grantResults.isNotEmpty() && grantResults.all { it == PackageManager.PERMISSION_GRANTED }) startRecording()
            else Toast.makeText(this, "Camera and microphone permissions are needed.", Toast.LENGTH_LONG).show()
        }
    }
}
