Screen Off Recorder — Android Studio project
App name: Screen Off Recorder
Target phone: Realme C35 (Android version/Realme UI may affect background camera behavior)

IMPORTANT:
- This ZIP is the Android source project, not a prebuilt APK.
- Open the folder in Android Studio, allow Gradle sync, then choose Build > Build APK(s).
- The APK is usually created under app/build/outputs/apk/debug/app-debug.apk.
- Use a recent Android Studio and JDK 17.
- Install on your own phone and grant Camera, Microphone, and Notifications permissions.
- Start recording while the app is visible. Once recording has started, you can lock the screen.
- Stop via the persistent notification's Stop action or reopen the app.
- Videos are saved to Movies/ScreenOffRecorder.
- Flashlight can be toggled using the app button or the notification action.
- Android/OEM policies and camera hardware can affect whether recording/torch continue while locked.
- This starter project has not been compiled or tested on a physical Realme C35. Build and test before relying on it.
- Respect local law and other people's privacy; record only where you have permission.
